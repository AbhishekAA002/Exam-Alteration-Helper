
<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Time table </title>

	<style type="text/css">
		.headin
		{
			font-size: 30px;
			text-align: center;
			
		}


    
    input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid black;
  border-radius: 4px;

  color: white;
}

	</style>
	<style>
    table {
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid black;
        padding: 5px;
    }

    .updated {
        background-color: red;
    }
</style>
</head>
<body style="background-image: url('https://th.bing.com/th/id/OIP.pENsrXZ3F7yXMHHRIHS22QHaEK?pid=ImgDet&rs=1');color: white;font-family: 'Montserrat', sans-serif;">





<!--Navigation bar -->

<div>

  <style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
  font-size: 18px;
}
</style>

  <ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a class="active" href="#home" style="background-color: whitesmoke;
  color: black;">Exam time table</a></li>
  <li><a href="#news">Exam Alteration</a></li>
  <li><a href="#contact">Feed back</a></li>
  <li><a href="#about">Contact us</a></li>
   <li style="float: right;"><a href="#about">Login</a></li>
</ul>
<br>
<div class="headin" style="color: white;">
Welcome Admistrator
</div>
<br>
<br>

<div >
<form method="POST" action="process.php" >
  
    
		<label for="name">Enter Date You Want To Modify The Exam (yyy/mm/dd):</label>
		<input style="color:Black" type="text" id="name" name="name" required><br>

    <label for="ename">Enter Exam Name You Want To Modify The Exam </label>
		<input style="color:Black" type="text" id="ename" name="ename" required><br>


    


		<label for="newname">Enter Modified Date :</label>
		<input style="color:Black" type="text" id="newname" name="newname" required>
		
    <label for="btime">Enter Modified Beginning time of exam  :</label>
		<input style="color:Black" type="text" id="btime" name="btime" required>

    <label for="etime">Enter Modified Ending time of exam  :</label>
		<input style="color:Black" type="text" id="etime" name="etime" required>

		<button type="submit">Submit</button>
	</form>
</div>

</body>
</html>